package bank;

public class CheckingAccount extends BankAccount {
	

    private int withdrawals;
	
	CheckingAccount(int accountNumber,double initialBalance){
		super(accountNumber,initialBalance);
		withdrawals = 0;
		}
	
	void deposit(int accountNumber){
		super.deposit(accountNumber);
	}
	
	void withdraw(double amount) {
    	super.withdraw(amount);
    	withdrawals++;
    	}
	
	void deductFees(){
		if(this.withdrawals > 3){
			if((withdrawals - 3)*2 > getBalance()){
				super.withdraw(getBalance());
			}
			else{
				super.withdraw((withdrawals - 3)*2);
			}
		}
	}
}
