package bank;

import java.util.ArrayList;


public class Bank {
	
	private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
	
	/*
	void addAccount(int accountNumber,double initialBalance){
		if(accounts.isEmpty() == false){
			if(accounts.indexOf(accountNumber) != -1){
				System.out.println("���b���w�g�Q�ϥ�");
				}
			else{
				accounts.add(new BankAccount(accountNumber,initialBalance));
				}
			}
		else{
			accounts.add(new BankAccount(accountNumber,initialBalance));
			}
		}
	*/
	
	void addCheckingAccount(int accountNumber,double initialBalance){
		if(accounts.isEmpty() == false){
			if(accounts.indexOf(accountNumber) != -1){
				System.out.println("���b���w�g�Q�ϥ�");
				}
			else{
				accounts.add(new CheckingAccount(accountNumber,initialBalance));
				}
			}
		else{
			accounts.add(new CheckingAccount(accountNumber,initialBalance));
			}
		}
	
	void addSavingsAccount(int accountNumber,double initialBalance,double interestRate){
		if(accounts.isEmpty() == false){
			if(accounts.indexOf(accountNumber) != -1){
				System.out.println("���b���w�g�Q�ϥ�");
				}
			else{
				accounts.add(new SavingsAccount(accountNumber,initialBalance,interestRate));
				}
			}
		else{
			accounts.add(new SavingsAccount(accountNumber,initialBalance,interestRate));
			}
		}
	
	void addInterest(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				if(((BankAccount)accounts.get(i)).getClass().getSimpleName().equals("SavingsAccount")){
					((SavingsAccount)accounts.get(i)).addInterest();
				}
			}
		}
	}
	
	void deductFees(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				if(((BankAccount)accounts.get(i)).getClass().getSimpleName().equals("CheckingAccount")){
					((CheckingAccount)accounts.get(i)).deductFees();
				}
			}
		}
		
	}
	
	void transfer(int withdrawAcctNum,int depositAcctNum, double amount){
		int x;
		String y = "";
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == withdrawAcctNum){
				if(((BankAccount)accounts.get(i)).getBalance() >= amount ){
					((BankAccount)accounts.get(i)).withdraw(amount);
					x = i;
					y = "Success";
				}
				else{
					y = "fall";
				}
			}
		}
		
		if(y.equals("Success")){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == depositAcctNum){
				if(((BankAccount)accounts.get(i)).accountNumber == depositAcctNum){
					((BankAccount)accounts.get(i)).deposit(amount);
					}
				}
			}
		}
	}
	
	boolean areEqualAccounts(int accountNumber1,int accountNumber2){
		int x = 0;
		int y = 0;
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber1){
				x = i;
				}
			}
		for (int n = 0 ; n < accounts.size(); n++){
			if(((BankAccount)accounts.get(n)).accountNumber == accountNumber2){
				y = n;
				}
			}
		if(((BankAccount)accounts.get(x)).equals(((BankAccount)accounts.get(y)))){
			return true;
			}
		else{
			return false;
			}
		}
	
	
	
	void deposit(int accountNumber,double initialBalance){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				((BankAccount)accounts.get(i)).deposit(initialBalance);
				}
			}
		}
	
	void withdraw(int accountNumber,double initialBalance){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				((BankAccount)accounts.get(i)).withdraw(initialBalance);
				}
			}
		}
	
	double getBalance(int accountNumber){
		double Bal = -1;
		for (int i = 0 ; i <= accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				Bal = ((BankAccount)accounts.get(i)).getBalance();
				}
			}
		if (Bal != -1){
			return Bal;
			}
		else{
			return -1;
			}
		}
	
	void suspendAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				((BankAccount)accounts.get(i)).suspend();
				}
			}
		}
	
	void reOpenAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				((BankAccount)accounts.get(i)).reOpen();
				}
			}
		}
	
	void closeAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				((BankAccount)accounts.get(i)).close();
				}
			}
		}
	
	
	String getAccountStatus(int accountNumber){
		String Sta = "";
		for (int i = 0 ; i <= accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				Sta = ((BankAccount)accounts.get(i)).getStatus() ;
				}
			}
		if (!Sta.equals("")){
			return "�d�L���b��";
			}
		else{
			return Sta;
			}
		}
	       
	String summarizeAccountTransactions(int accountNumber){
		String Sta = "";
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				Sta = ((BankAccount)accounts.get(i)).getTransactions();
				}
			}
		System.out.println(Sta);
		if (Sta.equals("") == true){
			return "�d�L���b��";
			}
		else{
			return Sta;
			}
		}
	
	String summarizeAllAccounts(){
		String Sta = "Bank Account Summary\n\nAccount     Type        Balance        #Transactions     Status\n";
		for (int i = 0 ; i < accounts.size(); i++){
			int acc = ((BankAccount)accounts.get(i)).accountNumber;
			String type = "";
			if(((BankAccount)accounts.get(i)) instanceof SavingsAccount){
				type = "saving";
			}
			else{
				type = "checking";
			}
			double Bal = ((BankAccount)accounts.get(i)).getBalance();
			int Tran = ((BankAccount)accounts.get(i)).retrieveNumberOfTransactions();
			String Status = ((BankAccount)accounts.get(i)).getStatus();
			Sta = Sta + String.format("%-12d%-12s%-21f%-12d%-10s\n",acc,type,Bal,Tran,Status);
		}
		Sta = Sta + "End of Account Summary";
		System.out.print(Sta);
		if (Sta.equals("") == true){
			return "";
			}
		else{
			return Sta;
			}
		}
	}
