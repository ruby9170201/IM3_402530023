package bank;

public class BankTester {
	BankTester(){
	}
	public static void main(String[] args){
		Bank B = new Bank();
		
		B.addCheckingAccount(1001, 0);
		B.addSavingsAccount(1002, 0, 10);
		B.addCheckingAccount(1003, 0);	
		B.addSavingsAccount(1004, 0, 10);
		
		B.deposit(1001,500);	
		B.deposit(1001,250);		
		B.deposit(1001,300);
		B.deposit(1001,50);
		B.deposit(1001,5000);
		B.withdraw(1001,500);
		B.withdraw(1001,500);
		B.withdraw(1001,500);
		B.withdraw(1001,500);
		B.withdraw(1001,500);
		B.deductFees(1001);		
		B.closeAccount(1001);		
		
		B.deposit(1002,2500);		
		B.deposit(1002,1500);		
		B.withdraw(1002,2000);	
		B.withdraw(1002,500);	
		B.addInterest(1002);		
		B.deposit(1002,4000);			
		B.suspendAccount(1002);	
				
		B.deposit(1003,1000);		
		B.deposit(1003,100);		
		B.withdraw(1003,250);		
		B.deposit(1003,750);		
		B.deposit(1004,750);				
		B.transfer(1003,1004,800);	 	
														
		B.summarizeAccountTransactions(1001);
		B.summarizeAccountTransactions(1002);
		B.summarizeAccountTransactions(1003);
		B.summarizeAccountTransactions(1004);
		
		B.summarizeAllAccounts();
	}
}
