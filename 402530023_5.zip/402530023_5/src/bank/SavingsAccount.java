package bank;

public class SavingsAccount extends BankAccount {

    
    private double interestRate;
    private double minBalance;
    
    SavingsAccount(int accountNumber,double initialBalance,double interestRate){
    	super(accountNumber,initialBalance);
    	this.interestRate = interestRate;
    	
    }
    
    void addInterest(){
    	minBalance = getBalance();
    	double interest = minBalance * interestRate /100;
    	deposit(interest);
    }
}
