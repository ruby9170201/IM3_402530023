import javax.swing.JOptionPane;

public class GradeAnalyzerTester {
	
	public static void main(String[] args){
		
		GradeAnalyzer.GradeAnalyse GA =	new	GradeAnalyzer.GradeAnalyse();
		String firstinput = JOptionPane.showInputDialog("�п�J���Z");
		GA.addGrade(Double.parseDouble(firstinput));
		GA.analyzeGrades();
		System.out.println(GA);
		
		}
}

