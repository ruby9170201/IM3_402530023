package bank;

import java.util.ArrayList;


public class Bank {
	
	private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
	
	void addAccount(int accountNumber,double initialBalance){
		if(accounts.isEmpty() == false){
			if(accounts.indexOf(accountNumber) != -1){
				System.out.println("���b���w�g�Q�ϥ�");
				}
			else{
				accounts.add(new BankAccount(accountNumber,initialBalance));
				}
			}
		else{
			accounts.add(new BankAccount(accountNumber,initialBalance));
			}
		}
	
	void deposit(int accountNumber,double initialBalance){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				((BankAccount)accounts.get(i)).deposit(initialBalance);
				}
			}
		}
	
	void withdraw(int accountNumber,double initialBalance){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				((BankAccount)accounts.get(i)).withdraw(initialBalance);
				}
			}
		}
	
	double getBalance(int accountNumber){
		double Bal = -1;
		for (int i = 0 ; i <= accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				Bal = ((BankAccount)accounts.get(i)).getBalance();
				}
			}
		if (Bal != -1){
			return Bal;
			}
		else{
			return -1;
			}
		}
	
	void suspendAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				((BankAccount)accounts.get(i)).suspend();
				}
			}
		}
	
	void reOpenAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				((BankAccount)accounts.get(i)).reOpen();
				}
			}
		}
	
	void closeAccount(int accountNumber){
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				((BankAccount)accounts.get(i)).close();
				}
			}
		}
	
	
	String getAccountStatus(int accountNumber){
		String Sta = "";
		for (int i = 0 ; i <= accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber==accountNumber){
				Sta = ((BankAccount)accounts.get(i)).getStatus();
				}
			}
		if (!Sta.equals("")){
			return "�d�L���b��";
			}
		else{
			return Sta;
			}
		}
	       
	String summarizeAccountTransacation(int accountNumber){
		String Sta = "";
		for (int i = 0 ; i < accounts.size(); i++){
			if(((BankAccount)accounts.get(i)).accountNumber == accountNumber){
				Sta = ((BankAccount)accounts.get(i)).getTransactions();
				}
			}
		if (Sta.equals("") == true){
			return "�d�L���b��";
			}
		else{
			return Sta;
			}
		}
	
	String summarizeAllAccounts(){
		String Sta = "Bank Account Summary\n\nAccount     Balance     #Transactions     Status\n";
		for (int i = 0 ; i < accounts.size(); i++){
			String acc = String.valueOf(((BankAccount)accounts.get(i)).accountNumber);
			String Bal = String.valueOf(((BankAccount)accounts.get(i)).getBalance());
			String Tran = String.valueOf(((BankAccount)accounts.get(i)).retrieveNumberOfTransactions());
			String Status = String.valueOf(((BankAccount)accounts.get(i)).getStatus());
			Sta = Sta + String.format("%-12s%-12s%-18s%-10s\n",acc,Bal,Tran,Status);
				}
		Sta = Sta + "End of Account Summary";
		if (Sta.equals("") == true){
			return "�d�L���b��";
			}
		else{
			return Sta;
			}
		}
	}
