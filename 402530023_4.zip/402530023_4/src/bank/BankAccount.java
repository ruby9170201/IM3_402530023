package bank;

import java.util.ArrayList;

public class BankAccount {
	
	    String state;
	    int accountNumber;
	    private double balance;
	    private ArrayList<Double> TransactionList = new ArrayList<Double>();

	    public BankAccount() {
	    	this(-1,-1);
	    }

	    public BankAccount(int anAccountNumber) {
	    	this.accountNumber = anAccountNumber;
	    	this.balance = 0;
	    	this.state = "open";
	    }

	    public BankAccount(int anAccountNumber, double initialBalance) {
	    	this.accountNumber = anAccountNumber;
	    	this.balance = initialBalance;
	    	this.state = "open";	
	    }

	    boolean isOpen() {
	    	if (this.state.equals("open")){
	    		return true;
	    	}else{
	    		return false;
	    		}
	    	}

	    boolean isSuspended() {
	    	if (this.state.equals("suspended")){
	    		return true;
	    	}else{
	    		return false;
	    		}
	        }
	    
	    boolean isClosed() {
	    	if (this.state.equals("closed")){
	    		return true;
	    	}else{
	    		return false;
	    		}
	    	}
	    void reOpen() {
	    	if(isOpen() == false){
	    		this.state = "open";
	    	}
	    }
	    
	    void suspend() {
	    	if(isSuspended() == false){
	    		this.state = "suspended";
	    	}
	    }
	    
	    void close() {
	    	if(isClosed() == false){
	    		reOpen();
	    		this.balance = 0;
	    		this.state = "close";
	    	}	
	    }
	    
	    void addTransaction(double amount){
	    	this.TransactionList.add(amount);
	    	}
	    

	    void deposit(double amount) {
	    	if (isOpen() == true && this.balance >= 0){
	    		this.balance = this.balance + amount;
	    		addTransaction(amount);
	    		}
	    	else{
	    		System.out.println("�нT�{�b���O�_�����`�}�Ҫ��A");
	    		}
	    	}

	    void withdraw(double amount) {
	    	if (isOpen() == true && this.balance >= 0 && amount <= this.balance){
	    		this.balance = this.balance - amount;
	    		addTransaction(0 - amount);
	    		}
	    	else{
	    		System.out.println("�нT�{�b���O�_�����`�}�Ҫ��A�Ϊ̾l�B����");
	    		}
	    	}
	    
	    String getTransactions() {
	    	String TransactionOutput = "";
	    	TransactionOutput = TransactionOutput + "Account #"+ this.accountNumber + " transactions:" + "\n";
	    	for(int i = 0 ; i < this.TransactionList.size(); i++){
	    		TransactionOutput = TransactionOutput + (i+1) + ": " + this.TransactionList.get(i) + "\n";
	    	}
	    	TransactionOutput = TransactionOutput + "End of transactions" + "\n";
	    	return TransactionOutput;
	    }
	    
	    double getBalance(){
	    	return this.balance;
	    	}
	    
	    String getStatus(){
	    	return this.state;
	    	}

	    int retrieveNumberOfTransactions() {
	        return TransactionList.size();
	        }
	    }

	
	
	
	

